# Xeno Mini CRM Project

This is a complete implementation of the Xeno SDE Internship Assignment for 2025.

## Features
- Customer and order ingestion APIs
- Campaign creation UI with segment rule builder
- Campaign delivery with dummy vendor API
- Delivery logging with simulated success/failure
- Google OAuth 2.0 authentication
- AI-powered prompt-to-rule segment builder (OpenAI API)
- Clean UI and responsive layout

## Tech Stack
- Frontend: React.js
- Backend: Node.js, Express.js
- Database: MongoDB
- AI Integration: OpenAI API
- Optional: Redis Streams for Pub/Sub

## Setup Instructions
1. Clone the repository.
2. Install dependencies in `frontend/` and `backend/` folders using `npm install`.
3. Set up MongoDB and environment variables.
4. Run backend using `npm run dev` and frontend using `npm start`.

## AI Tools Used
- OpenAI GPT for converting natural language to segmentation rules.

## Limitations
- AI message generation is mocked with sample output.
- Redis Streams used for demonstration and may need production optimization.
